import json
import cv2
import numpy as np

from pathlib import Path
from collections import defaultdict
from itertools import combinations

# ==================================================
# PROJECT PATHS
# ==================================================

BASE_DIR = Path(__file__).resolve().parent.parent

TRACKING_DIR = BASE_DIR / "output" / "tracking_data"
VIDEO_DIR = BASE_DIR / "sample_videos"
OUTPUT_DIR = BASE_DIR / "output" / "spatial_analysis"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ==================================================
# CONFIGURATION
# ==================================================

PROXIMITY_THRESHOLD = 0.08
MOVEMENT_THRESHOLD = 0.002

MIN_OBSERVATIONS = 5
MIN_DURATION = 1.0

TREND_WINDOW_RATIO = 0.30

GAP_MULTIPLIER = 2.5

SUPPORTED_FORMATS = {".mp4", ".avi", ".mov", ".mkv"}


# ==================================================
# VIDEO DIAGONAL
# ==================================================

def get_frame_diagonal(video_name):

    videos = [
        file for file in VIDEO_DIR.rglob("*")
        if file.is_file()
        and file.suffix.lower() in SUPPORTED_FORMATS
        and file.stem == video_name
    ]

    if not videos:
        print("Video not found. Using fallback diagonal.")
        return 2202.9

    cap = cv2.VideoCapture(str(videos[0]))

    if not cap.isOpened():
        return 2202.9

    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

    cap.release()

    diagonal = np.hypot(width, height)

    return diagonal if diagonal > 0 else 2202.9


# ==================================================
# SAMPLING INTERVAL
# ==================================================

def calculate_sampling_interval(frame_timestamps):

    timestamps = sorted(set(frame_timestamps.values()))

    intervals = [
        timestamps[i] - timestamps[i - 1]
        for i in range(1, len(timestamps))
        if timestamps[i] > timestamps[i - 1]
    ]

    if not intervals:
        return None

    return float(np.median(intervals))


# ==================================================
# PROXIMITY GAP DETECTION
# ==================================================

def split_proximity_episodes(observations, max_gap):

    if not observations:
        return []

    observations.sort(
        key=lambda item: item["timestamp"]
    )

    episodes = []
    current_episode = [observations[0]]

    for observation in observations[1:]:

        previous = current_episode[-1]

        time_gap = (
            observation["timestamp"] - previous["timestamp"]
        )

        if time_gap > max_gap:

            episodes.append(current_episode)

            current_episode = [observation]

        else:

            current_episode.append(observation)

    episodes.append(current_episode)

    return episodes


# ==================================================
# DISTANCE TREND ANALYSIS
# ==================================================

def analyze_distance_trend(observations):

    if len(observations) < MIN_OBSERVATIONS:
        return "uncertain"

    distances = np.array(
        [item["distance"] for item in observations],
        dtype=float
    )

    window_size = max(
        2,
        int(len(distances) * TREND_WINDOW_RATIO)
    )

    first_median = float(
        np.median(distances[:window_size])
    )

    last_median = float(
        np.median(distances[-window_size:])
    )

    change = first_median - last_median

    if change > MOVEMENT_THRESHOLD:
        return "approaching"

    elif change < -MOVEMENT_THRESHOLD:
        return "moving_apart"

    return "nearby"


# ==================================================
# PROXIMITY DURATION
# ==================================================

def classify_proximity(observations):

    first_time = observations[0]["timestamp"]
    last_time = observations[-1]["timestamp"]

    duration = max(0, last_time - first_time)

    if (
        len(observations) >= MIN_OBSERVATIONS
        and duration >= MIN_DURATION
    ):
        return "sustained", duration

    return "temporary", duration


# ==================================================
# EPISODE QUALITY FILTERING
# ==================================================

def classify_episode_quality(observations, duration):

    if len(observations) < MIN_OBSERVATIONS:
        return "uncertain"

    if duration < MIN_DURATION:
        return "short_encounter"

    return "reliable"


# ==================================================
# SPATIAL ANALYSIS
# ==================================================

def analyze_video(json_file):

    video_name = json_file.stem

    print(f"\nAnalyzing spatial relationships: {video_name}")

    with open(json_file, "r") as file:
        records = json.load(file)

    if not isinstance(records, list):
        print("Invalid tracking JSON format. Skipping.")
        return

    diagonal = get_frame_diagonal(video_name)

    frames = defaultdict(list)
    frame_timestamps = {}

    # Group objects by frame
    for record in records:

        required = {
            "frame",
            "track_id",
            "object",
            "centroid",
            "timestamp"
        }

        if not isinstance(record, dict):
            continue

        if not required.issubset(record):
            continue

        try:
            frame_number = int(record["frame"])
            timestamp = float(record["timestamp"])

            centroid = np.array(
                record["centroid"], dtype=float
            )

            if (
                centroid.shape != (2,)
                or not np.all(np.isfinite(centroid))
                or not np.isfinite(timestamp)
            ):
                continue

        except (ValueError, TypeError):
            continue

        frames[frame_number].append(record)

        frame_timestamps[frame_number] = timestamp

    # Determine actual sampling interval
    sampling_interval = calculate_sampling_interval(
        frame_timestamps
    )

    if sampling_interval is None:
        print("Insufficient timestamps for gap detection.")
        return

    max_gap = sampling_interval * GAP_MULTIPLIER

    print(
        "Expected sampling interval:",
        round(sampling_interval, 3)
    )

    print(
        "Maximum allowed gap:",
        round(max_gap, 3)
    )

    pair_history = defaultdict(list)
    pair_labels = {}

    # ==================================================
    # COMPARE OBJECTS IN THE SAME FRAME
    # ==================================================

    for frame_number, objects in sorted(frames.items()):

        for obj1, obj2 in combinations(objects, 2):

            id1 = obj1["track_id"]
            id2 = obj2["track_id"]

            if id1 == id2:
                continue

            pair_key = tuple(
                sorted((id1, id2), key=str)
            )

            point1 = np.array(
                obj1["centroid"], dtype=float
            )

            point2 = np.array(
                obj2["centroid"], dtype=float
            )

            distance = float(
                np.linalg.norm(point1 - point2) / diagonal
            )

            # Store consistent object labels
            if pair_key not in pair_labels:

                labels = {
                    id1: obj1["object"],
                    id2: obj2["object"]
                }

                pair_labels[pair_key] = [
                    labels[pair_key[0]],
                    labels[pair_key[1]]
                ]

            # Store nearby objects
            if distance <= PROXIMITY_THRESHOLD:

                pair_history[pair_key].append({

                    "frame": frame_number,

                    "timestamp": float(
                        obj1["timestamp"]
                    ),

                    "distance": round(distance, 6)

                })

    # ==================================================
    # GENERATE PROXIMITY EPISODES
    # ==================================================

    relationships = []

    for pair_key, observations in pair_history.items():

        episodes = split_proximity_episodes(
            observations,
            max_gap
        )

        for episode_number, episode in enumerate(
            episodes, start=1
        ):

            distances = [
                item["distance"] for item in episode
            ]

            timestamps = [
                item["timestamp"] for item in episode
            ]

            trend = analyze_distance_trend(episode)

            proximity_type, duration = classify_proximity(
                episode
            )

            evidence_category = classify_episode_quality(
                episode,
                duration
            )

            relationships.append({

                "episode_id": episode_number,

                "track_ids": list(pair_key),

                "object_1": pair_labels[pair_key][0],

                "object_2": pair_labels[pair_key][1],

                "first_seen": timestamps[0],

                "last_seen": timestamps[-1],

                "duration_seconds": round(duration, 3),

                "observations": len(episode),

                "minimum_distance": round(
                    min(distances), 6
                ),

                "maximum_distance": round(
                    max(distances), 6
                ),

                "average_distance": round(
                    float(np.mean(distances)), 6
                ),

                "proximity_type": proximity_type,

                "relationship": trend,

                "evidence_category": evidence_category

            })

    # ==================================================
    # SUMMARY
    # ==================================================

    summary = {

        "approaching": 0,
        "moving_apart": 0,
        "nearby": 0,
        "uncertain": 0,

        "temporary": 0,
        "sustained": 0,

        "reliable": 0,
        "short_encounter": 0,
        "uncertain_evidence": 0

    }

    for relationship in relationships:

        summary[relationship["relationship"]] += 1

        summary[relationship["proximity_type"]] += 1

        category = relationship["evidence_category"]

        if category == "uncertain":

            summary["uncertain_evidence"] += 1

        else:

            summary[category] += 1

    # ==================================================
    # OUTPUT DATA
    # ==================================================

    output = {

        "video": video_name,

        "total_relationships": len(relationships),

        "total_proximity_episodes": len(relationships),

        "analysis_settings": {

            "proximity_threshold": PROXIMITY_THRESHOLD,

            "movement_threshold": MOVEMENT_THRESHOLD,

            "minimum_observations": MIN_OBSERVATIONS,

            "minimum_duration_seconds": MIN_DURATION,

            "sampling_interval_seconds": round(
                sampling_interval, 4
            ),

            "gap_multiplier": GAP_MULTIPLIER,

            "maximum_gap_seconds": round(max_gap, 4),

            "episode_filtering": {

                "minimum_observations": MIN_OBSERVATIONS,

                "minimum_duration_seconds": MIN_DURATION,

                "categories": [
                    "reliable",
                    "short_encounter",
                    "uncertain"
                ]

            }

        },

        "summary": summary,

        "relationships": relationships

    }

    # ==================================================
    # SAVE JSON
    # ==================================================

    output_file = OUTPUT_DIR / f"{video_name}_spatial.json"

    with open(output_file, "w") as file:

        json.dump(output, file, indent=4)

    print("Proximity episodes found:", len(relationships))

    print("Reliable episodes:", summary["reliable"])

    print("Short encounters:", summary["short_encounter"])

    print("Uncertain episodes:", summary["uncertain_evidence"])

    print("Summary:", summary)

    print("Saved:", output_file)


# ==================================================
# MAIN
# ==================================================

def main():

    files = list(TRACKING_DIR.glob("*.json"))

    if not files:
        print("No tracking files found!")
        return

    print("NEMESIS-X Spatial Analyzer V4")

    print("Tracking files found:", len(files))

    for file in files:

        try:
            analyze_video(file)

        except Exception as error:

            print(f"Error processing {file.name}: {error}")

    print("\nSpatial Relationship Analysis V4 Completed!")


if __name__ == "__main__":
    main()