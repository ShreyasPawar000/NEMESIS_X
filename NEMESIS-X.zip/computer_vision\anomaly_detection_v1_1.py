import sqlite3
import json
from pathlib import Path
from collections import defaultdict
from datetime import datetime


# Project paths
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR.parent / "output"
DB_PATH = OUTPUT_DIR / "event_memory.db"

REPORT_DIR = OUTPUT_DIR / "anomaly_detection"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def load_events():
    if not DB_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    with sqlite3.connect(DB_PATH) as connection:
        connection.row_factory = sqlite3.Row
        events = connection.execute("SELECT * FROM events").fetchall()

    return [dict(event) for event in events]


def get_time(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def create_alert(event, alert_type, description, priority):
    return {
        "video": event["video_name"],
        "person_track_id": event["person_track_id"],
        "object_track_id": event["object_track_id"],
        "object_class": event["object_class"],
        "start_time": event["start_time"],
        "end_time": event["end_time"],
        "association_score": event["association_score"],
        "classification": event["classification"],
        "alert_type": alert_type,
        "description": description,
        "review_priority": priority
    }


def detect_patterns(events):
    anomaly_candidates = []
    review_flags = []
    object_events = defaultdict(list)
    zero_duration_records = 0
    invalid_interval_records = 0

    for event in events:
        classification = (event["classification"] or "").lower()

        start = get_time(event["start_time"])
        end = get_time(event["end_time"])

        if start is None or end is None or end < start:
            invalid_interval_records += 1
        elif end == start:
            zero_duration_records += 1

        if event["object_track_id"] is not None:
            key = (event["video_name"], event["object_track_id"])
            object_events[key].append(event)

        # Shared-object-use candidate
        if "shared_object_use" in classification:
            anomaly_candidates.append(create_alert(
                event,
                "shared_object_use_candidate",
                "Possible shared-object-use pattern requires visual verification.",
                "medium"
            ))

        # Ambiguous association
        if "ambiguous" in classification:
            review_flags.append(create_alert(
                event,
                "ambiguous_association",
                "Multiple interpretations may be possible.",
                "medium"
            ))

        # Competing association
        if "competing" in classification:
            review_flags.append(create_alert(
                event,
                "competing_association",
                "Association has competing candidates.",
                "medium"
            ))

        # Insufficient evidence
        if "insufficient" in classification:
            review_flags.append(create_alert(
                event,
                "insufficient_evidence",
                "Evidence is insufficient for a reliable association.",
                "low"
            ))

        # Weak association
        if "weak" in classification:
            review_flags.append(create_alert(
                event,
                "weak_association",
                "Association has weak supporting evidence.",
                "low"
            ))

    # Detect multiple people only when their intervals overlap
    for (video_name, object_id), records in object_events.items():

        valid_records = []

        for event in records:
            start = get_time(event["start_time"])
            end = get_time(event["end_time"])

            if start is not None and end is not None and end > start:
                person_id = event["person_track_id"]

                if person_id is not None:
                    valid_records.append({
                        "person": person_id,
                        "start": start,
                        "end": end,
                        "event": event
                    })

        # Compare distinct people associated with the same object
        for i, first in enumerate(valid_records):
            for second in valid_records[i + 1:]:

                if first["person"] == second["person"]:
                    continue

                overlap_start = max(first["start"], second["start"])
                overlap_end = min(first["end"], second["end"])

                if overlap_end > overlap_start:
                    anomaly_candidates.append({
                        "video": video_name,
                        "person_track_id": [
                            first["person"],
                            second["person"]
                        ],
                        "object_track_id": object_id,
                        "object_class": first["event"]["object_class"],
                        "start_time": overlap_start,
                        "end_time": overlap_end,
                        "association_score": None,
                        "classification": "overlapping_person_candidates",
                        "alert_type": "overlapping_multi_person_association",
                        "description": (
                            f"Two distinct person tracks have overlapping "
                            f"association intervals with object track {object_id}. "
                            "This may indicate shared use or competing associations."
                        ),
                        "review_priority": "medium"
                    })

    return (
        anomaly_candidates,
        review_flags,
        zero_duration_records,
        invalid_interval_records
    )


def generate_report(events, candidates, flags, zero_count, invalid_count):

    candidate_summary = defaultdict(int)
    flag_summary = defaultdict(int)
    video_summary = defaultdict(lambda: {
        "anomaly_candidates": 0,
        "review_flags": 0
    })

    for alert in candidates:
        candidate_summary[alert["alert_type"]] += 1
        video_summary[alert["video"]]["anomaly_candidates"] += 1

    for flag in flags:
        flag_summary[flag["alert_type"]] += 1
        video_summary[flag["video"]]["review_flags"] += 1

    report = {
        "module": "NEMESIS-X Anomaly Detection V1.1",
        "generated_at": datetime.now().isoformat(),
        "total_event_records": len(events),

        "total_anomaly_candidates": len(candidates),
        "total_review_flags": len(flags),

        "anomaly_candidate_summary": dict(candidate_summary),
        "review_flag_summary": dict(flag_summary),

        "data_quality": {
            "zero_duration_records": zero_count,
            "invalid_interval_records": invalid_count
        },

        "per_video_summary": dict(video_summary),

        "interpretation": (
            "Anomaly candidates identify patterns that deserve investigation. "
            "Review flags indicate uncertainty or competing interpretations. "
            "Neither category establishes suspicious activity or wrongdoing. "
            "All findings require human verification."
        ),

        "anomaly_candidates": candidates,
        "review_flags": flags
    }

    report_path = REPORT_DIR / "anomaly_report_v1_1.json"

    with open(report_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=4)

    return report_path, candidate_summary, flag_summary


def main():
    print("\n========== NEMESIS-X ANOMALY DETECTION V1.1 ==========")

    try:
        events = load_events()
        print(f"\nEvent records loaded: {len(events)}")

        candidates, flags, zero_count, invalid_count = detect_patterns(events)

        report_path, candidate_summary, flag_summary = generate_report(
            events, candidates, flags, zero_count, invalid_count
        )

        print(f"\nAnomaly candidates: {len(candidates)}")
        print(f"Review flags: {len(flags)}")

        print("\n--- ANOMALY CANDIDATES ---")
        for name, count in sorted(candidate_summary.items()):
            print(f"{name}: {count}")

        print("\n--- REVIEW FLAGS ---")
        for name, count in sorted(flag_summary.items()):
            print(f"{name}: {count}")

        print("\n--- DATA QUALITY ---")
        print(f"Zero-duration records: {zero_count}")
        print(f"Invalid intervals: {invalid_count}")

        print("\nReport saved:")
        print(report_path)

        print("\nAnomaly Detection V1.1 completed.")

    except Exception as error:
        print(f"\nERROR: {error}")


if __name__ == "__main__":
    main()