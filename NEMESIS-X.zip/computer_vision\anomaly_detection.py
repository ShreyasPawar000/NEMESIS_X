import sqlite3
import json
from pathlib import Path
from collections import defaultdict
from datetime import datetime


# Project paths
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR.parent / "output"
DB_PATH = OUTPUT_DIR / "event_memory.db"

REPORT_DIR = OUTPUT_DIR / "anomaly_detection"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def load_events():
    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"Event Memory database not found: {DB_PATH}"
        )

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row

    events = connection.execute(
        "SELECT * FROM events"
    ).fetchall()

    connection.close()
    return [dict(event) for event in events]


def create_alert(event, alert_type, description, priority):
    return {
        "video": event["video_name"],
        "person_track_id": event["person_track_id"],
        "object_track_id": event["object_track_id"],
        "object_class": event["object_class"],
        "start_time": event["start_time"],
        "end_time": event["end_time"],
        "association_score": event["association_score"],
        "classification": event["classification"],
        "alert_type": alert_type,
        "description": description,
        "review_priority": priority
    }


def detect_patterns(events):
    alerts = []

    object_people = defaultdict(set)
    object_events = defaultdict(list)

    for event in events:
        key = (
            event["video_name"],
            event["object_track_id"]
        )

        if event["object_track_id"] is not None:
            object_people[key].add(event["person_track_id"])
            object_events[key].append(event)

        classification = (
            event["classification"] or ""
        ).lower()

        # Shared-object-use candidates
        if "shared_object_use" in classification:
            alerts.append(create_alert(
                event,
                "shared_object_use",
                "Object is associated with multiple people.",
                "medium"
            ))

        # Ambiguous associations
        if "ambiguous" in classification:
            alerts.append(create_alert(
                event,
                "ambiguous_association",
                "Multiple interpretations may be possible.",
                "medium"
            ))

        # Competing associations
        if "competing" in classification:
            alerts.append(create_alert(
                event,
                "competing_association",
                "Person-object association has competing candidates.",
                "medium"
            ))

        # Insufficient evidence
        if "insufficient" in classification:
            alerts.append(create_alert(
                event,
                "insufficient_evidence",
                "Available evidence is insufficient for a reliable association.",
                "low"
            ))

        # Weak associations
        if classification == "weak_association_candidate":
            alerts.append(create_alert(
                event,
                "weak_association",
                "Association has relatively weak supporting evidence.",
                "low"
            ))

    # Check objects associated with multiple distinct people
    for key, people in object_people.items():
        if len(people) > 1:
            video_name, object_id = key

            alerts.append({
                "video": video_name,
                "person_track_id": None,
                "object_track_id": object_id,
                "object_class": object_events[key][0]["object_class"],
                "start_time": min(
                    e["start_time"] for e in object_events[key]
                    if e["start_time"] is not None
                ),
                "end_time": max(
                    e["end_time"] for e in object_events[key]
                    if e["end_time"] is not None
                ),
                "association_score": None,
                "classification": "multiple_person_candidates",
                "alert_type": "multi_person_object_association",
                "description": (
                    f"Object track {object_id} has association "
                    f"records involving {len(people)} distinct people."
                ),
                "review_priority": "medium"
            })

    return alerts


def generate_report(events, alerts):
    counts = defaultdict(int)

    for alert in alerts:
        counts[alert["alert_type"]] += 1

    report = {
        "module": "NEMESIS-X Anomaly Detection V1",
        "generated_at": datetime.now().isoformat(),
        "total_event_records": len(events),
        "total_alerts": len(alerts),
        "alert_summary": dict(counts),
        "interpretation": (
            "Alerts identify patterns for human review. "
            "They do not establish suspicious activity or wrongdoing."
        ),
        "alerts": alerts
    }

    report_path = REPORT_DIR / "anomaly_report_v1.json"

    with open(report_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=4)

    return report_path, counts


def main():
    print("\n========== NEMESIS-X ANOMALY DETECTION V1 ==========")

    try:
        events = load_events()

        print(f"\nEvent records loaded: {len(events)}")

        alerts = detect_patterns(events)

        report_path, counts = generate_report(
            events, alerts
        )

        print(f"\nTotal review alerts: {len(alerts)}")

        print("\n--- ALERT SUMMARY ---")

        for alert_type, count in sorted(counts.items()):
            print(f"{alert_type}: {count}")

        print("\nReport saved:")
        print(report_path)

        print("\nAnomaly Detection V1 completed.")

    except Exception as error:
        print(f"\nERROR: {error}")


if __name__ == "__main__":
    main()
