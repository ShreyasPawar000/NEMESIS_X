
import streamlit as st

def render():

    st.markdown(
        '<div class="nav-label">OVERVIEW / INTELLIGENCE CENTER</div>',
        unsafe_allow_html=True
    )

    st.title("Command Center")

    st.caption(
        "Your central workspace for understanding video events."
    )

    st.markdown("---")

    # ANALYTICS
    st.markdown("### Intelligence Overview")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("VIDEOS ANALYZED", "06", "Sample data")
    c2.metric("OBJECT TRACKS", "493", "Sample data")
    c3.metric("MOVEMENT EVENTS", "20,269", "Sample data")
    c4.metric("ANOMALIES", "—", "Awaiting integration")

    st.markdown("<br>", unsafe_allow_html=True)

    # WORKSPACE
    left, right = st.columns([1.65, 1])

    with left:
        st.markdown("### Intelligence Workspace")

        st.markdown("""
            <div style="
                background:#191719;
                border:1px solid #33292c;
                border-radius:12px;
                padding:25px;
                min-height:210px;
            ">
                <div style="
                    color:#c04452;
                    font-size:11px;
                    letter-spacing:2px;
                ">
                    NEMESIS-X / VIDEO INTELLIGENCE
                </div>

                <h2 style="margin-top:20px;">
                    See beyond the frame.
                </h2>

                <p style="color:#968c8e;">
                    Investigate video sequences, understand
                    interactions, and discover potentially
                    significant events.
                </p>
            </div>
        """, unsafe_allow_html=True)

    with right:
        st.markdown("### System Status")

        st.markdown("""
            <div style="
                background:#191719;
                border:1px solid #33292c;
                border-radius:12px;
                padding:20px;
            ">
                <p style="color:#d7a56d;">
                    ● Frontend initialized
                </p>

                <p style="color:#968c8e;">
                    ○ Computer vision integration pending
                </p>

                <p style="color:#968c8e;">
                    ○ Backend integration pending
                </p>

                <p style="color:#968c8e;">
                    ○ Event intelligence pending
                </p>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # MODULES
    st.markdown("### Investigation Modules")

    a, b, c = st.columns(3)

    with a:
        st.markdown("**01 / Video Intelligence**")
        st.caption("Upload and examine video footage.")

    with b:
        st.markdown("**02 / Event Explorer**")
        st.caption("Explore activities across time.")

    with c:
        st.markdown("**03 / NEMESIS AI**")
        st.caption("Question your video and retrieve evidence.")

    st.markdown("---")

    st.caption(
        "NEMESIS-X / CRIMSON PROTOCOL / VIDEO INTELLIGENCE"
    )
