  ],
  "frame_embedding": null
}''', language="json")
    st.caption("Bounding boxes use normalized [x1, y1, x2, y2] coordinates from 0.0 to 1.0. Frame embeddings are optional.")

elif page == "Anomaly Desk":
    section_heading("01 / EVIDENCE REGISTER", "Alerts returned by the reasoner")
    if not st.session_state.alerts:
        st.markdown('<div class="empty-panel"><div>◎</div><b>Nothing flagged in this session</b><p>The engine needs at least 10 frames in memory and a score of 0.65 or above to emit an alert. It first calibrates on 50 frames.</p></div>', unsafe_allow_html=True)
    for index, alert in enumerate(reversed(st.session_state.alerts), 1):
        with st.expander(f'{index:02d}  /  {alert.get("event_id", "EVENT")}  /  SCORE {alert.get("anomaly_score", 0):.3f}', expanded=index == 1):
            st.write(alert.get("explanation", "No explanation supplied."))
            x, y, z = st.columns(3)
            x.metric("VIDEO ID", alert.get("video_id", "—"))
            y.metric("START", f'{alert.get("start_time", 0):.2f}s')
            z.metric("END", f'{alert.get("end_time", 0):.2f}s')
            st.write("**Involved track IDs**")
            st.write(", ".join(map(str, alert.get("involved_track_ids", []))) or "—")
            st.write("**Evidence frame IDs**")
            st.write(", ".join(map(str, alert.get("evidence_frames", []))) or "—")
    st.markdown('<div class="caution"><b>EVIDENCE LIMITATION</b><p>The current API returns evidence frame IDs, not the actual image files or clips. This page displays the IDs and explanation supplied by the backend.</p></div>', unsafe_allow_html=True)

elif page == "Frame Ingest":
    section_heading("01 / FRAME RELAY", "Transmit a frame to the reasoning engine")
    st.markdown('<p class="intro">A test console for the exact FramePayload accepted by FastAPI. This page does not perform object detection.</p>', unsafe_allow_html=True)
    import json
    from components.api import post_frame
    example = {
        "video_id": "camera_north_01", "frame_id": 1, "timestamp": 0.04,
        "detections": [
            {"track_id": 1, "label": "person", "confidence": 0.94, "bbox": [0.1, 0.2, 0.3, 0.8]},
            {"track_id": 2, "label": "person", "confidence": 0.91, "bbox": [0.6, 0.2, 0.8, 0.8]}
        ],
        "frame_embedding": None
    }
    raw = st.text_area("JSON FRAME PAYLOAD", json.dumps(example, indent=2), height=330)
    if st.button("TRANSMIT FRAME", type="primary", use_container_width=True):
        try:
            payload = json.loads(raw)
            result, error = post_frame(api_url, payload)
            if error:
                st.error(error)
            else:
                st.session_state.last_ingest = result
                alert = result.get("alert")
                if alert:
                    st.session_state.alerts.append(alert)
                    st.warning("The backend returned an anomaly alert.")
                else:
                    st.success("Frame accepted.")
                st.json(result)
        except json.JSONDecodeError as exc:
            st.error(f"Invalid JSON: {exc}")
    if st.session_state.last_ingest:
        section_heading("02 / LAST RESPONSE", "Backend acknowledgement")
        st.json(st.session_state.last_ingest)


elif page == "NEMESIS AI":
    section_heading("01 / INVESTIGATION ASSISTANT", "Ask questions about your footage")
    st.markdown(
        '<p class="intro">NEMESIS AI is an interactive investigation assistant concept. '
        'This chat interface is currently a frontend prototype; it is not connected to an AI model '
        'or the video-analysis pipeline yet.</p>',
        unsafe_allow_html=True
    )
    st.markdown(
        '<div class="caution"><b>PROTOTYPE MODE</b><p>Responses below are demonstration messages, '
        'not findings generated from your actual video footage.</p></div>',
        unsafe_allow_html=True
    )
    if not st.session_state.chat_history:
        st.markdown(
            '<div class="empty-panel"><div>◈</div><b>Start an investigation</b>'
            '<p>Try asking: "What unusual activity was detected?" or '
            '"When did the latest alert occur?"</p></div>',
            unsafe_allow_html=True
        )
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    question = st.chat_input("Ask NEMESIS AI about the footage...")
    if question:
        st.session_state.chat_history.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)
        if st.session_state.alerts:
            latest = st.session_state.alerts[-1]
            answer = (
                "This is a prototype response, not an AI-generated investigation. "
                f"The latest alert currently stored in this session has score "
                f"{latest.get('anomaly_score', 0):.3f}, video ID "
                f"{latest.get('video_id', '—')}, and explanation: "
                f"{latest.get('explanation', 'No explanation supplied.')}"
            )
        else:
            answer = (
                "NEMESIS AI is not connected to an AI model yet, so I cannot analyse "
                "the footage or verify suspicious activity. Once the AI service and "
                "video-analysis data are integrated, you will be able to ask questions "
                "about detected events, timestamps, and tracked objects."
            )
        st.session_state.chat_history.append({"role": "assistant", "content": answer})
        with st.chat_message("assistant"):
            st.markdown(answer)
    if st.button("CLEAR CONVERSATION"):
        st.session_state.chat_history = []
        st.rerun()

elif page == "System Status":
    section_heading("01 / SERVICE HEALTH", "Reasoning engine connection")
    if health:
        st.success("FastAPI health endpoint responded.")
        st.json(health)
    else:
        st.error("Backend unavailable. Start FastAPI and verify the URL in the sidebar.")
    st.markdown('<div class="rule"></div>', unsafe_allow_html=True)
    section_heading("02 / ROUTE MAP", "Available backend interfaces")
    for method, route, detail in [
        ("GET", "/api/v1/health", "Health status, buffer depth and calibration state"),
        ("POST", "/api/v1/ingest", "Submit a frame and receive score / optional alert"),
        ("WS", "/ws/events", "WebSocket broadcast for anomaly alerts")
    ]:
        st.markdown(f'<div class="route"><code>{method}</code><b>{route}</b><span>{detail}</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="caution"><b>NOT IMPLEMENTED IN THE SUPPLIED BACKEND</b><p>Video upload/decoding, object detection, tracker execution, relation graphs, evidence image retrieval and persistent alert history require additional CV/backend integration.</p></div>', unsafe_allow_html=True)

st.markdown('<div class="footer">NEMESIS-X &nbsp; / &nbsp; TEMPORAL REASONING &nbsp; / &nbsp; HUMAN REVIEW REQUIRED</div>', unsafe_allow_html=True)
