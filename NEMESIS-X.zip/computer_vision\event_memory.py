import json
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime


# Project directories
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR.parent / "output"

INPUT_DIR = OUTPUT_DIR / "temporal_event_analysis_v4_3"
DB_PATH = OUTPUT_DIR / "event_memory.db"


def connect_db():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row

    connection.execute("""
        CREATE TABLE IF NOT EXISTS video_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            video_name TEXT UNIQUE,
            source_file TEXT,
            processed_at TEXT,
            summary_json TEXT
        )
    """)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_key TEXT UNIQUE,
            video_name TEXT,
            person_track_id INTEGER,
            object_track_id INTEGER,
            object_class TEXT,
            start_time REAL,
            end_time REAL,
            association_score REAL,
            classification TEXT,
            original_classification TEXT,
            spatial_evidence TEXT,
            ambiguity INTEGER,
            movement_analysis TEXT,
            resolution_segments TEXT,
            segment_summary TEXT,
            raw_json TEXT,
            FOREIGN KEY(video_name)
                REFERENCES video_sources(video_name)
        )
    """)

    connection.commit()
    return connection


def create_event_key(video_name, association):
    raw = json.dumps(
        association,
        sort_keys=True,
        separators=(",", ":")
    )

    unique_data = video_name + raw
    return hashlib.sha256(unique_data.encode()).hexdigest()


def import_video_file(connection, file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        data = json.load(file)

    video_name = data.get("video", file_path.stem)

    connection.execute("""
        INSERT INTO video_sources
        (video_name, source_file, processed_at, summary_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(video_name) DO UPDATE SET
            source_file = excluded.source_file,
            processed_at = excluded.processed_at,
            summary_json = excluded.summary_json
    """, (
        video_name,
        str(file_path),
        datetime.now().isoformat(timespec="seconds"),
        json.dumps(data.get("summary", {}))
    ))

    associations = data.get("associations", [])

    for association in associations:
        event_key = create_event_key(video_name, association)

        movement = association.get("movement_analysis", {})
        segments = association.get("resolution_segments", [])
        segment_summary = association.get(
            "segment_decision_summary", {}
        )

        connection.execute("""
            INSERT OR IGNORE INTO events (
                event_key,
                video_name,
                person_track_id,
                object_track_id,
                object_class,
                start_time,
                end_time,
                association_score,
                classification,
                original_classification,
                spatial_evidence,
                ambiguity,
                movement_analysis,
                resolution_segments,
                segment_summary,
                raw_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event_key,
            video_name,
            association.get("person_track_id"),
            association.get("object_track_id"),
            association.get("object_class"),
            association.get("start_time"),
            association.get("end_time"),
            association.get("association_score"),
            association.get("association_classification"),
            association.get("original_classification"),
            association.get("spatial_evidence"),
            int(bool(association.get("association_ambiguity", False))),
            json.dumps(movement),
            json.dumps(segments),
            json.dumps(segment_summary),
            json.dumps(association)
        ))

    connection.commit()

    print(
        f"Imported: {video_name} | "
        f"Associations: {len(associations)}"
    )


def import_all():
    if not INPUT_DIR.exists():
        print(f"\nInput folder not found:\n{INPUT_DIR}")
        print("Check the V4.3 output folder name.")
        return

    files = list(INPUT_DIR.glob("*_temporal_events_v4_3.json"))

    if not files:
        print("No V4.3 JSON files found.")
        return

    connection = connect_db()

    for file_path in files:
        try:
            import_video_file(connection, file_path)
        except Exception as error:
            print(f"Failed: {file_path.name} | {error}")

    connection.close()
    print("\nEvent Memory import completed.")


def search_events():
    connection = connect_db()

    print("\n--- EVENT MEMORY SEARCH ---")
    print("1. Search by video")
    print("2. Search by person ID")
    print("3. Search by object class")
    print("4. Search shared-object-use candidates")

    choice = input("\nSelect option: ").strip()

    if choice == "1":
        value = input("Enter video name: ").strip()
        query = "SELECT * FROM events WHERE video_name LIKE ?"
        params = (f"%{value}%",)

    elif choice == "2":
        value = input("Enter person track ID: ").strip()
        query = "SELECT * FROM events WHERE person_track_id = ?"
        params = (value,)

    elif choice == "3":
        value = input("Enter object class: ").strip()
        query = "SELECT * FROM events WHERE object_class LIKE ?"
        params = (f"%{value}%",)

    elif choice == "4":
        query = """
            SELECT * FROM events
            WHERE classification LIKE '%shared_object_use%'
        """
        params = ()

    else:
        print("Invalid option.")
        connection.close()
        return

    results = connection.execute(query, params).fetchall()

    print(f"\nFound {len(results)} event records.")

    for event in results[:30]:
        print("-" * 45)
        print("Video:", event["video_name"])
        print("Person ID:", event["person_track_id"])
        print("Object:", event["object_class"])
        print("Object ID:", event["object_track_id"])
        print("Time:", event["start_time"], "-", event["end_time"])
        print("Score:", event["association_score"])
        print("Classification:", event["classification"])

    connection.close()


def show_statistics():
    connection = connect_db()

    videos = connection.execute(
        "SELECT COUNT(*) FROM video_sources"
    ).fetchone()[0]

    events = connection.execute(
        "SELECT COUNT(*) FROM events"
    ).fetchone()[0]

    print("\n--- EVENT MEMORY STATISTICS ---")
    print("Videos stored:", videos)
    print("Event records stored:", events)
    print("Database:", DB_PATH)

    connection.close()


def main():
    while True:
        print("\n========== NEMESIS-X EVENT MEMORY ==========")
        print("1. Import V4.3 event files")
        print("2. Search event memory")
        print("3. Show database statistics")
        print("4. Exit")

        choice = input("\nEnter choice: ").strip()

        if choice == "1":
            import_all()
        elif choice == "2":
            search_events()
        elif choice == "3":
            show_statistics()
        elif choice == "4":
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()