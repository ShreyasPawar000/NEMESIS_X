import json
import cv2
import numpy as np
from pathlib import Path
from collections import defaultdict

BASE_DIR = Path(__file__).resolve().parent.parent
TRACKING_DIR = BASE_DIR / "output" / "tracking_data"
VIDEO_DIR = BASE_DIR / "sample_videos"
OUTPUT_DIR = BASE_DIR / "output" / "movement_analysis_v2"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

MIN_OBSERVATIONS = 5
SMOOTHING_WINDOW = 3
MOVEMENT_THRESHOLD = 0.005


def get_video_diagonal(video_name):
    video_path = VIDEO_DIR / f"{video_name}.mp4"

    cap = cv2.VideoCapture(str(video_path))

    if not cap.isOpened():
        return 2202.9

    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

    cap.release()

    return np.hypot(width, height)


def smooth_centroids(points):
    smoothed = []

    for i in range(len(points)):
        start = max(0, i - 1)
        end = min(len(points), i + 2)

        window = points[start:end]
        smoothed.append(np.median(window, axis=0))

    return np.array(smoothed)


def analyze_track(rows, frame_diagonal):
    rows = sorted(rows, key=lambda x: x["timestamp"])

    track_id = rows[0]["track_id"]
    object_name = rows[0]["object"]

    if len(rows) < MIN_OBSERVATIONS:
        return {
            "track_id": track_id,
            "object": object_name,
            "observations": len(rows),
            "movement_status": "insufficient_data"
        }

    points = np.array(
        [row["centroid"] for row in rows],
        dtype=float
    )

    timestamps = np.array(
        [row["timestamp"] for row in rows],
        dtype=float
    )

    smoothed = smooth_centroids(points)

    distances = np.linalg.norm(
        np.diff(smoothed, axis=0),
        axis=1
    )

    time_gaps = np.diff(timestamps)

    valid = time_gaps > 0

    speeds = distances[valid] / time_gaps[valid]

    if len(speeds) == 0:
        return {
            "track_id": track_id,
            "object": object_name,
            "observations": len(rows),
            "movement_status": "insufficient_data"
        }

    normalized_speeds = speeds / frame_diagonal

    median_speed = float(np.median(normalized_speeds))
    max_speed = float(np.percentile(normalized_speeds, 95))

    total_distance = float(np.sum(distances))

    if median_speed >= MOVEMENT_THRESHOLD:
        status = "moving"
    else:
        status = "stationary"

    return {
        "track_id": track_id,
        "object": object_name,
        "first_seen": float(timestamps[0]),
        "last_seen": float(timestamps[-1]),
        "observations": len(rows),
        "total_distance_pixels": round(total_distance, 2),
        "median_normalized_speed": round(median_speed, 6),
        "p95_normalized_speed": round(max_speed, 6),
        "movement_status": status
    }


def process_video(json_file):

    video_name = json_file.stem
    print(f"\nAnalyzing: {video_name}")

    with open(json_file, "r") as file:
        records = json.load(file)

    frame_diagonal = get_video_diagonal(video_name)

    tracks = defaultdict(list)

    for record in records:
        tracks[record["track_id"]].append(record)

    summaries = []

    for rows in tracks.values():
        result = analyze_track(rows, frame_diagonal)
        summaries.append(result)

    moving = sum(
        x["movement_status"] == "moving"
        for x in summaries
    )

    stationary = sum(
        x["movement_status"] == "stationary"
        for x in summaries
    )

    insufficient = sum(
        x["movement_status"] == "insufficient_data"
        for x in summaries
    )

    output = {
        "video": video_name,
        "total_tracks": len(summaries),
        "moving_tracks": moving,
        "stationary_tracks": stationary,
        "insufficient_data_tracks": insufficient,
        "track_summaries": summaries
    }

    output_file = OUTPUT_DIR / f"{video_name}_movement_v2.json"

    with open(output_file, "w") as file:
        json.dump(output, file, indent=4)

    print(f"Total tracks: {len(summaries)}")
    print(f"Moving: {moving}")
    print(f"Stationary: {stationary}")
    print(f"Insufficient data: {insufficient}")
    print(f"Saved: {output_file}")


def main():

    json_files = list(TRACKING_DIR.glob("*.json"))

    if not json_files:
        print("No tracking JSON files found!")
        return

    for json_file in json_files:
        process_video(json_file)

    print("\nMovement Analyzer V2 completed!")


if __name__ == "__main__":
    main()