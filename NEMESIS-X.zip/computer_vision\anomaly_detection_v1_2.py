import sqlite3
import json
from pathlib import Path
from collections import defaultdict
from datetime import datetime
from itertools import combinations


# Configuration
MIN_OVERLAP_DURATION = 0.5

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR.parent / "output"
DB_PATH = OUTPUT_DIR / "event_memory.db"

REPORT_DIR = OUTPUT_DIR / "anomaly_detection"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def load_events():
    if not DB_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    with sqlite3.connect(DB_PATH) as connection:
        connection.row_factory = sqlite3.Row
        return [
            dict(row)
            for row in connection.execute("SELECT * FROM events")
        ]


def get_time(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def get_score(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def create_alert(event, alert_type, description, priority):
    return {
        "video": event["video_name"],
        "person_track_id": event["person_track_id"],
        "object_track_id": event["object_track_id"],
        "object_class": event["object_class"],
        "start_time": event["start_time"],
        "end_time": event["end_time"],
        "association_score": event["association_score"],
        "classification": event["classification"],
        "alert_type": alert_type,
        "description": description,
        "review_priority": priority
    }


def merge_intervals(intervals):
    if not intervals:
        return []

    intervals.sort(key=lambda x: x["start"])
    merged = [intervals[0].copy()]

    for current in intervals[1:]:
        previous = merged[-1]

        if current["start"] <= previous["end"]:
            previous["end"] = max(
                previous["end"], current["end"]
            )

            scores = [
                score for score in [
                    previous["score"], current["score"]
                ] if score is not None
            ]

            previous["score"] = max(scores) if scores else None

        else:
            merged.append(current.copy())

    return merged


def get_priority(duration, score):
    if duration >= 2.0 and score is not None and score >= 0.80:
        return "high"

    if duration >= 1.0 and score is not None and score >= 0.50:
        return "medium"

    return "low"


def detect_patterns(events):

    anomaly_candidates = []
    review_flags = []

    object_people = defaultdict(lambda: defaultdict(list))

    zero_duration = 0
    invalid_intervals = 0

    for event in events:

        classification = (
            event["classification"] or ""
        ).lower()

        start = get_time(event["start_time"])
        end = get_time(event["end_time"])

        if start is None or end is None or end < start:
            invalid_intervals += 1

        elif start == end:
            zero_duration += 1

        # Existing shared-object-use candidates
        if "shared_object_use" in classification:
            anomaly_candidates.append(create_alert(
                event,
                "shared_object_use_candidate",
                "Possible shared-object-use pattern requiring visual verification.",
                "medium"
            ))

        # Uncertainty and competing evidence
        if "ambiguous" in classification:
            review_flags.append(create_alert(
                event,
                "ambiguous_association",
                "Multiple interpretations may be possible.",
                "medium"
            ))

        if "competing" in classification:
            review_flags.append(create_alert(
                event,
                "competing_association",
                "Association has competing candidates.",
                "medium"
            ))

        if "insufficient" in classification:
            review_flags.append(create_alert(
                event,
                "insufficient_evidence",
                "Evidence is insufficient for a reliable association.",
                "low"
            ))

        if "weak" in classification:
            review_flags.append(create_alert(
                event,
                "weak_association",
                "Association has weak supporting evidence.",
                "low"
            ))

        # Only supported association candidates enter overlap analysis
        accepted = any(label in classification for label in [
            "strong_association",
            "possible_association",
            "weak_association",
            "best_supported",
            "shared_object_use"
        ])

        if not accepted:
            continue

        if (
            start is None or end is None or end <= start
            or event["object_track_id"] is None
            or event["person_track_id"] is None
        ):
            continue

        key = (
            event["video_name"],
            event["object_track_id"]
        )

        person_id = event["person_track_id"]

        object_people[key][person_id].append({
            "start": start,
            "end": end,
            "score": get_score(event["association_score"])
        })

    # Multi-person overlap detection
    for (video_name, object_id), people in object_people.items():

        merged_people = {}

        for person_id, intervals in people.items():
            merged_people[person_id] = merge_intervals(intervals)

        for person_a, person_b in combinations(
            merged_people.keys(), 2
        ):

            episodes = []

            for interval_a in merged_people[person_a]:
                for interval_b in merged_people[person_b]:

                    overlap_start = max(
                        interval_a["start"],
                        interval_b["start"]
                    )

                    overlap_end = min(
                        interval_a["end"],
                        interval_b["end"]
                    )

                    duration = overlap_end - overlap_start

                    if duration >= MIN_OVERLAP_DURATION:

                        scores = [
                            score for score in [
                                interval_a["score"],
                                interval_b["score"]
                            ] if score is not None
                        ]

                        conservative_score = (
                            min(scores) if scores else None
                        )

                        episodes.append({
                            "start": overlap_start,
                            "end": overlap_end,
                            "score": conservative_score
                        })

            # Consolidate duplicate and overlapping episodes
            episodes = merge_intervals(episodes)

            for episode in episodes:

                duration = episode["end"] - episode["start"]

                priority = get_priority(
                    duration, episode["score"]
                )

                anomaly_candidates.append({
                    "video": video_name,
                    "person_track_id": [person_a, person_b],
                    "object_track_id": object_id,
"object_class": next(
    (
        event["object_class"]
        for event in events
        if event["video_name"] == video_name
        and event["object_track_id"] == object_id
    ),
    None
),
                    "start_time": round(episode["start"], 3),
                    "end_time": round(episode["end"], 3),
                    "duration": round(duration, 3),
                    "association_score": episode["score"],
                    "classification": "overlapping_person_candidates",
                    "alert_type": "overlapping_multi_person_association",
                    "description": (
                        "Two distinct person tracks have supported "
                        "association intervals overlapping with the "
                        "same object. Visual verification is required."
                    ),
                    "review_priority": priority
                })

    return (
        anomaly_candidates,
        review_flags,
        zero_duration,
        invalid_intervals
    )


def generate_report(events, candidates, flags, zero_count, invalid_count):

    candidate_summary = defaultdict(int)
    flag_summary = defaultdict(int)

    video_summary = defaultdict(lambda: {
        "anomaly_candidates": 0,
        "review_flags": 0
    })

    for alert in candidates:
        candidate_summary[alert["alert_type"]] += 1
        video_summary[alert["video"]]["anomaly_candidates"] += 1

    for flag in flags:
        flag_summary[flag["alert_type"]] += 1
        video_summary[flag["video"]]["review_flags"] += 1

    report = {
        "module": "NEMESIS-X Anomaly Detection V1.2",
        "generated_at": datetime.now().isoformat(),

        "configuration": {
            "minimum_overlap_duration_seconds": MIN_OVERLAP_DURATION
        },

        "total_event_records": len(events),
        "total_anomaly_candidates": len(candidates),
        "total_review_flags": len(flags),

        "anomaly_candidate_summary": dict(candidate_summary),
        "review_flag_summary": dict(flag_summary),

        "data_quality": {
            "zero_duration_records": zero_count,
            "invalid_interval_records": invalid_count
        },

        "per_video_summary": dict(video_summary),

        "interpretation": (
            "Anomaly candidates are patterns requiring investigation. "
            "Review flags represent uncertainty or competing evidence. "
            "These results do not establish suspicious activity or "
            "wrongdoing. Human verification is required."
        ),

        "anomaly_candidates": candidates,
        "review_flags": flags
    }

    report_path = REPORT_DIR / "anomaly_report_v1_2.json"

    with open(report_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=4)

    return report_path, candidate_summary, flag_summary


def main():

    print("\n========== NEMESIS-X ANOMALY DETECTION V1.2 ==========")

    try:
        events = load_events()

        print(f"\nEvent records loaded: {len(events)}")

        candidates, flags, zero_count, invalid_count = (
            detect_patterns(events)
        )

        report_path, candidate_summary, flag_summary = (
            generate_report(
                events,
                candidates,
                flags,
                zero_count,
                invalid_count
            )
        )

        print(f"\nAnomaly candidates: {len(candidates)}")
        print(f"Review flags: {len(flags)}")

        print("\n--- ANOMALY CANDIDATES ---")
        for name, count in sorted(candidate_summary.items()):
            print(f"{name}: {count}")

        print("\n--- REVIEW FLAGS ---")
        for name, count in sorted(flag_summary.items()):
            print(f"{name}: {count}")

        print("\n--- DATA QUALITY ---")
        print(f"Zero-duration records: {zero_count}")
        print(f"Invalid intervals: {invalid_count}")

        print("\nReport saved:")
        print(report_path)

        print("\nAnomaly Detection V1.2 completed.")

    except Exception as error:
        print(f"\nERROR: {error}")


if __name__ == "__main__":
    main()