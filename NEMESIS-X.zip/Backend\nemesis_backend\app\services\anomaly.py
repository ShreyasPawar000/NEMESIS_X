import numpy as np
from sklearn.ensemble import IsolationForest
from typing import Optional, List


class AnomalyEngine:
    def __init__(self, warmup_frames: int = 50, contamination: float = 0.05):
        self.warmup_frames = warmup_frames
        self.detector = IsolationForest(
            contamination=contamination,
            random_state=42
        )

        self.warmup_samples: List[np.ndarray] = []
        self.is_calibrated = False

        self.baseline_embedding: Optional[np.ndarray] = None
        self.embedding_count = 0

        self.expected_features = 10

    def score(
        self,
        kinematic_feats: np.ndarray,
        frame_embedding: Optional[List[float]] = None
    ) -> float:

        features = np.asarray(kinematic_feats, dtype=np.float32).flatten()

        if features.size != self.expected_features:
            raise ValueError(
                f"Expected {self.expected_features} features, "
                f"received {features.size}"
            )

        if not np.all(np.isfinite(features)):
            raise ValueError("Kinematic features contain invalid values")

        # Learn normal scene behaviour
        if not self.is_calibrated:
            self.warmup_samples.append(features.copy())

            if frame_embedding is not None:
                emb = np.asarray(frame_embedding, dtype=np.float32)

                if np.all(np.isfinite(emb)):
                    if self.baseline_embedding is None:
                        self.baseline_embedding = emb.copy()
                    elif emb.shape == self.baseline_embedding.shape:
                        self.baseline_embedding += emb
                    else:
                        raise ValueError("Embedding dimensions do not match")

                    self.embedding_count += 1

            if len(self.warmup_samples) >= self.warmup_frames:
                self.detector.fit(
                    np.asarray(self.warmup_samples, dtype=np.float32)
                )

                if self.embedding_count > 0:
                    self.baseline_embedding /= self.embedding_count

                self.is_calibrated = True

            return 0.0

        # Kinematic anomaly score
        raw_score = self.detector.decision_function([features])[0]

        kinematic_score = float(
            np.clip(0.5 - (raw_score * 0.5), 0.0, 1.0)
        )

        # Semantic deviation score
        semantic_score = 0.0

        if frame_embedding is not None and self.baseline_embedding is not None:
            emb = np.asarray(frame_embedding, dtype=np.float32)

            if emb.shape == self.baseline_embedding.shape:
                denominator = (
                    np.linalg.norm(emb)
                    * np.linalg.norm(self.baseline_embedding)
                ) + 1e-7

                cosine_similarity = float(
                    np.dot(emb, self.baseline_embedding) / denominator
                )

                cosine_similarity = float(
                    np.clip(cosine_similarity, -1.0, 1.0)
                )

                semantic_score = float(
                    np.clip(1.0 - cosine_similarity, 0.0, 1.0)
                )

        # Combined anomaly score
        final_score = (
            0.6 * kinematic_score +
            0.4 * semantic_score
        )

        return round(float(final_score), 3)