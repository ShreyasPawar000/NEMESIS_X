import json
import math
from pathlib import Path
from collections import Counter


# ==========================================
# PATH CONFIGURATION
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent

MOVEMENT_DIR = BASE_DIR / "output" / "movement_analysis_v2"
SPATIAL_DIR = BASE_DIR / "output" / "spatial_analysis"
TRACKING_DIR = BASE_DIR / "output" / "tracking_data"

OUTPUT_DIR = BASE_DIR / "output" / "temporal_event_analysis_v2"


# ==========================================
# OBJECT ASSOCIATION CONFIGURATION
# ==========================================

PORTABLE_OBJECTS = {
    "backpack", "handbag", "suitcase",
    "umbrella", "bottle"
}

VEHICLE_OBJECTS = {
    "bicycle", "car", "motorcycle",
    "bus", "truck"
}

PERSON_CLASS = "person"

MIN_ASSOCIATION_OBSERVATIONS = 5
ASSOCIATION_DISTANCE_THRESHOLD = 0.08


# ==========================================
# DATA LOADER
# ==========================================

def load_json(path):

    if not path.exists():
        raise FileNotFoundError(f"Missing file: {path}")

    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


# ==========================================
# INPUT VALIDATION
# ==========================================

def validate_inputs(video_name):

    movement_file = MOVEMENT_DIR / f"{video_name}_movement_v2.json"
    spatial_file = SPATIAL_DIR / f"{video_name}_spatial.json"
    tracking_file = TRACKING_DIR / f"{video_name}.json"

    movement = load_json(movement_file)
    spatial = load_json(spatial_file)
    tracking = load_json(tracking_file)

    if movement.get("video") != video_name:
        raise ValueError("Movement video name mismatch")

    if spatial.get("video") != video_name:
        raise ValueError("Spatial video name mismatch")

    required_keys = {
        "frame", "timestamp", "track_id",
        "object", "centroid"
    }

    for index, record in enumerate(tracking):

        missing = required_keys - record.keys()

        if missing:
            raise ValueError(
                f"Tracking record {index} missing: {missing}"
            )

        if len(record["centroid"]) != 2:
            raise ValueError(
                f"Invalid centroid in tracking record {index}"
            )

    return movement, spatial, tracking


# ==========================================
# TRACK INDEX
# ==========================================

def build_track_index(tracking):

    tracks = {}

    for record in tracking:

        track_id = record["track_id"]

        tracks.setdefault(track_id, []).append(record)

    for track_id in tracks:

        tracks[track_id].sort(
            key=lambda item: item["timestamp"]
        )

    return tracks


# ==========================================
# PERSON-OBJECT MOVEMENT ANALYSIS
# ==========================================

def calculate_movement_similarity(
    person_data,
    object_data,
    start_time,
    end_time
):

    person_positions = {
        item["frame"]: item["centroid"]
        for item in person_data
        if start_time <= item["timestamp"] <= end_time
    }

    object_positions = {
        item["frame"]: item["centroid"]
        for item in object_data
        if start_time <= item["timestamp"] <= end_time
    }

    common_frames = sorted(
        set(person_positions) & set(object_positions)
    )

    if len(common_frames) < MIN_ASSOCIATION_OBSERVATIONS:
        return None

    direction_scores = []
    relative_distances = []

    for index in range(1, len(common_frames)):

        frame_a = common_frames[index - 1]
        frame_b = common_frames[index]

        px1, py1 = person_positions[frame_a]
        px2, py2 = person_positions[frame_b]

        ox1, oy1 = object_positions[frame_a]
        ox2, oy2 = object_positions[frame_b]

        pdx, pdy = px2 - px1, py2 - py1
        odx, ody = ox2 - ox1, oy2 - oy1

        person_speed = math.hypot(pdx, pdy)
        object_speed = math.hypot(odx, ody)

        if person_speed > 0 and object_speed > 0:

            similarity = (
                pdx * odx + pdy * ody
            ) / (person_speed * object_speed)

            direction_scores.append(similarity)

        relative_distances.append(
            math.hypot(px2 - ox2, py2 - oy2)
        )

    if not direction_scores:
        return None

    distance_range = (
        max(relative_distances) - min(relative_distances)
        if relative_distances else None
    )

    average_distance = (
        sum(relative_distances) / len(relative_distances)
        if relative_distances else None
    )

    distance_stability = None

    if average_distance and average_distance > 0:
        distance_stability = round(
            distance_range / average_distance, 4
        )

    return {
        "shared_observations": len(common_frames),
        "direction_similarity": round(
            sum(direction_scores) / len(direction_scores), 4
        ),
        "relative_distance_range_pixels": round(
            distance_range, 2
        ) if distance_range is not None else None,
        "relative_distance_stability": distance_stability
    }


# ==========================================
# PERSON-OBJECT ASSOCIATION
# ==========================================

def analyze_person_object_associations(tracks, relationships):

    associations = []

    for relationship in relationships:

        first_id, second_id = relationship["track_ids"]

        first_object = relationship["object_1"]
        second_object = relationship["object_2"]

        if (
            first_object == PERSON_CLASS
            and second_object in PORTABLE_OBJECTS
        ):
            person_id, object_id = first_id, second_id
            object_class = second_object

        elif (
            second_object == PERSON_CLASS
            and first_object in PORTABLE_OBJECTS
        ):
            person_id, object_id = second_id, first_id
            object_class = first_object

        else:
            continue

        if person_id not in tracks or object_id not in tracks:
            continue

        average_spatial_distance = relationship.get(
            "average_distance"
        )

        if (
            average_spatial_distance is None
            or average_spatial_distance > ASSOCIATION_DISTANCE_THRESHOLD
        ):
            continue

        movement = calculate_movement_similarity(
            tracks[person_id],
            tracks[object_id],
            relationship["first_seen"],
            relationship["last_seen"]
        )

        if movement is None:

            classification = "insufficient_evidence"

        elif (
            movement["direction_similarity"] >= 0.70
            and movement["relative_distance_stability"] is not None
            and movement["relative_distance_stability"] <= 0.25
        ):

            classification = "strong_candidate"

        elif movement["direction_similarity"] >= 0.30:

            classification = "possible_candidate"

        else:

            classification = "weak_candidate"

        associations.append({

            "person_track_id": person_id,
            "object_track_id": object_id,
            "object_class": object_class,

            "start_time": relationship["first_seen"],
            "end_time": relationship["last_seen"],

            "spatial_evidence": relationship["evidence_category"],

            "movement_similarity": movement,

            "association_classification": classification

        })

    return associations


# ==========================================
# EVENT SUMMARY
# ==========================================

def generate_summary(associations):

    counts = Counter(
        item["association_classification"]
        for item in associations
    )

    return {
        "total_associations": len(associations),
        "strong_candidates": counts["strong_candidate"],
        "possible_candidates": counts["possible_candidate"],
        "weak_candidates": counts["weak_candidate"],
        "insufficient_evidence": counts["insufficient_evidence"]
    }


# ==========================================
# VIDEO ANALYSIS
# ==========================================

def analyze_video(video_name):

    print("\n" + "=" * 65)
    print(f"PROCESSING VIDEO: {video_name}")
    print("=" * 65)

    movement, spatial, tracking = validate_inputs(video_name)

    tracks = build_track_index(tracking)

    relationships = spatial.get("relationships", [])

    associations = analyze_person_object_associations(
        tracks,
        relationships
    )

    summary = generate_summary(associations)

    result = {

        "video": video_name,

        "module": "Temporal Event Reasoning V2",

        "input_sources": {
            "movement_analysis": str(MOVEMENT_DIR),
            "spatial_analysis": str(SPATIAL_DIR),
            "tracking_data": str(TRACKING_DIR)
        },

        "summary": summary,

        "associations": associations

    }

    output_file = (
        OUTPUT_DIR /
        f"{video_name}_temporal_events_v2.json"
    )

    with open(output_file, "w", encoding="utf-8") as file:

        json.dump(
            result,
            file,
            indent=4,
            ensure_ascii=False
        )

    print("Movement tracks:", movement["total_tracks"])
    print("Spatial episodes:", len(relationships))
    print("Tracking observations:", len(tracking))
    print("Person-object associations:", len(associations))

    print("\nAssociation summary:")

    for key, value in summary.items():
        print(f"{key}: {value}")

    print("Saved:", output_file.name)

    return result


# ==========================================
# MAIN
# ==========================================

def main():

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    movement_files = sorted(
        MOVEMENT_DIR.glob("*_movement_v2.json")
    )

    if not movement_files:
        print("No movement analysis files found.")
        return

    successful = 0
    failed = 0

    for file in movement_files:

        video_name = file.name.replace(
            "_movement_v2.json", ""
        )

        try:

            analyze_video(video_name)
            successful += 1

        except Exception as error:

            print(f"\nERROR processing {video_name}: {error}")
            failed += 1

    print("\n" + "=" * 65)
    print("TEMPORAL EVENT REASONING V2 RESULTS")
    print("=" * 65)

    print("Successfully processed:", successful)
    print("Failed:", failed)

    print("Output directory:", OUTPUT_DIR)


if __name__ == "__main__":
    main()