import json
import math
from pathlib import Path
from collections import defaultdict

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent

INPUT_DIR = PROJECT_DIR / "output" / "tracking_data"
OUTPUT_DIR = PROJECT_DIR / "output" / "movement_analysis"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

STATIONARY_THRESHOLD = 0.005


def distance(p1, p2):
    return math.sqrt(
        (p2[0] - p1[0]) ** 2 +
        (p2[1] - p1[1]) ** 2
    )


def analyze_video(json_file):

    with open(json_file, "r") as file:
        records = json.load(file)

    if not records:
        print("No tracking records:", json_file.name)
        return

    tracks = defaultdict(list)

    max_x = max(r["bbox"][2] for r in records)
    max_y = max(r["bbox"][3] for r in records)

    diagonal = math.sqrt(max_x ** 2 + max_y ** 2)

    for record in records:
        tracks[record["track_id"]].append(record)

    summaries = []
    movement_events = []

    for track_id, observations in tracks.items():

        observations.sort(key=lambda x: x["timestamp"])

        total_distance = 0
        speeds = []
        directions = []

        for i in range(1, len(observations)):

            previous = observations[i - 1]
            current = observations[i]

            dt = current["timestamp"] - previous["timestamp"]

            if dt <= 0:
                continue

            p1 = previous["centroid"]
            p2 = current["centroid"]

            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]

            displacement = distance(p1, p2)
            speed = displacement / dt

            normalized_speed = speed / diagonal

            total_distance += displacement
            speeds.append(normalized_speed)

            direction = []

            if abs(dx) > 3:
                direction.append("right" if dx > 0 else "left")

            if abs(dy) > 3:
                direction.append("down" if dy > 0 else "up")

            directions.append(direction)

            movement_events.append({
                "track_id": track_id,
                "object": current["object"],
                "timestamp": current["timestamp"],
                "speed_pixels_per_second": round(speed, 2),
                "normalized_speed": round(normalized_speed, 5),
                "direction": direction
            })

        average_speed = (
            sum(speeds) / len(speeds) if speeds else 0
        )

        status = (
            "moving"
            if average_speed > STATIONARY_THRESHOLD
            else "stationary"
        )

        summaries.append({
            "track_id": track_id,
            "object": observations[0]["object"],
            "first_seen": observations[0]["timestamp"],
            "last_seen": observations[-1]["timestamp"],
            "observations": len(observations),
            "total_distance_pixels": round(total_distance, 2),
            "average_normalized_speed": round(average_speed, 5),
            "maximum_normalized_speed": round(max(speeds, default=0), 5),
            "movement_status": status
        })

    output = {
        "video": json_file.stem,
        "total_tracks": len(tracks),
        "moving_tracks": sum(
            x["movement_status"] == "moving" for x in summaries
        ),
        "stationary_tracks": sum(
            x["movement_status"] == "stationary" for x in summaries
        ),
        "track_summaries": summaries,
        "movement_events": movement_events
    }

    output_file = OUTPUT_DIR / f"{json_file.stem}_movement.json"

    with open(output_file, "w") as file:
        json.dump(output, file, indent=4)

    print(f"\nVideo: {json_file.name}")
    print("Total tracks:", len(tracks))
    print("Moving:", output["moving_tracks"])
    print("Stationary:", output["stationary_tracks"])
    print("Saved:", output_file)


if not INPUT_DIR.exists():
    print("Tracking data folder not found!")
else:
    files = list(INPUT_DIR.glob("*.json"))

    if not files:
        print("No JSON files found!")
    else:
        for file in files:
            analyze_video(file)

print("\nMovement Analysis Completed!")