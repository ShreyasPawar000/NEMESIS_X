from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from typing import List, Optional
import asyncio
import traceback

from app.schemas import FramePayload, AnomalyAlert
from app.memory.temporal_buffer import TemporalMemory
from app.services.anomaly import AnomalyEngine
from app.services.reasoner import EvidenceReasoner
from app.services.llm_explainer import generate_explanation


app = FastAPI(title="NEMESIS-X Reasoning Engine")


# ==========================================
# CONFIGURATION
# ==========================================

video_sessions = {}
connected_clients: List[WebSocket] = []

ANOMALY_TRIGGER = 0.65
NORMAL_FRAMES_TO_RESET = 5


# ==========================================
# PER-VIDEO SESSION MANAGEMENT
# ==========================================

def get_video_session(video_id: str):

    if video_id not in video_sessions:

        video_sessions[video_id] = {
            "memory": TemporalMemory(window_size=40),

            "detector": AnomalyEngine(
                warmup_frames=50,
                contamination=0.08
            ),

            "alert_active": False,
            "normal_frames": 0
        }

        print(f"[SESSION] Created: {video_id}")

    return video_sessions[video_id]


# ==========================================
# WEBSOCKET BROADCAST
# ==========================================

async def broadcast_alert(alert):

    message = alert.model_dump_json()
    dead_connections = []

    for client in connected_clients:

        try:
            await client.send_text(message)

        except Exception as error:
            print("[WEBSOCKET ERROR]", error)
            dead_connections.append(client)

    for client in dead_connections:

        if client in connected_clients:
            connected_clients.remove(client)


# ==========================================
# WEBSOCKET CONNECTION
# ==========================================

@app.websocket("/ws/events")
async def websocket_endpoint(ws: WebSocket):

    await ws.accept()
    connected_clients.append(ws)

    print("[WEBSOCKET] Client connected")

    try:

        while True:
            await ws.receive_text()

    except WebSocketDisconnect:

        if ws in connected_clients:
            connected_clients.remove(ws)

        print("[WEBSOCKET] Client disconnected")


# ==========================================
# GEMINI INCIDENT REPORT
# ==========================================

async def generate_incident_report(alert, frames):

    print("\n[GEMINI] Generating incident report...")

    try:

        explanation = await asyncio.to_thread(
            generate_explanation,
            alert,
            frames
        )

        if explanation and explanation.strip():

            print("[GEMINI] Incident report generated successfully")

            return explanation.strip()

        print("[GEMINI] No report returned. Using fallback.")

    except Exception:

        print("[GEMINI ERROR]")
        traceback.print_exc()

    return alert.explanation


# ==========================================
# FRAME INGESTION API
# ==========================================

@app.post("/api/v1/ingest")
async def ingest_frame(frame: FramePayload):

    session = get_video_session(frame.video_id)

    memory = session["memory"]
    detector = session["detector"]

    # Store frame
    memory.push(frame)

    # Extract temporal features
    feats = memory.extract_interaction_vector()

    # Calculate anomaly score
    score = detector.score(
        feats,
        frame.frame_embedding
    )

    print(
        f"[ANALYSIS] Video={frame.video_id} | "
        f"Frame={frame.frame_id} | "
        f"Objects={len(frame.detections)} | "
        f"Score={score:.3f} | "
        f"Calibrated={detector.is_calibrated}"
    )

    alert_payload: Optional[AnomalyAlert] = None

    # ======================================
    # ANOMALY DETECTION
    # ======================================

    if score >= ANOMALY_TRIGGER and len(memory.frames) >= 10:

        session["normal_frames"] = 0

        if not session["alert_active"]:

            session["alert_active"] = True

            print(
                f"\n[ALERT] New anomaly detected: "
                f"{frame.video_id} | Score={score:.3f}"
            )

            # Generate evidence-based alert
            alert_payload = EvidenceReasoner.generate_alert(
                window=list(memory.frames),
                score=score,
                video_id=frame.video_id
            )

            # ==================================
            # GENERATE GEMINI REPORT
            # ==================================

            explanation = await generate_incident_report(
                alert_payload,
                list(memory.frames)
            )

            # Update alert with full report
            alert_payload = alert_payload.model_copy(
                update={
                    "explanation": explanation
                }
            )

            # ==================================
            # BROADCAST TO FRONTEND
            # ==================================

            await broadcast_alert(alert_payload)

            print("[ALERT] Processing completed")

        else:

            print(
                f"[ALERT ACTIVE] Existing event | "
                f"Video={frame.video_id}"
            )

    else:

        session["normal_frames"] += 1

        if session["normal_frames"] >= NORMAL_FRAMES_TO_RESET:

            if session["alert_active"]:
                print(
                    f"[ALERT RESET] Video={frame.video_id}"
                )

            session["alert_active"] = False

    # ======================================
    # API RESPONSE
    # ======================================

    return {
        "status": "ok",
        "video_id": frame.video_id,
        "calibrated": detector.is_calibrated,
        "score": score,
        "alert_triggered": alert_payload is not None,
        "alert": alert_payload
    }


# ==========================================
# HEALTH MONITORING
# ==========================================

@app.get("/api/v1/health")
def health():

    return {
        "status": "healthy",

        "active_video_sessions": len(video_sessions),

        "sessions": {

            video_id: {

                "buffer_depth": len(
                    session["memory"].frames
                ),

                "calibrated": session["detector"].is_calibrated,

                "alert_active": session["alert_active"],

                "normal_frames": session["normal_frames"]

            }

            for video_id, session in video_sessions.items()
        }
    }