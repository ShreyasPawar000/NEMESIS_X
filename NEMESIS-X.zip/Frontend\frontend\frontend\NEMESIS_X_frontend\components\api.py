import requests

def get_health(base_url: str):
    try:
        response = requests.get(f"{base_url.rstrip('/')}/api/v1/health", timeout=2.5)
        response.raise_for_status()
        return response.json()
    except requests.RequestException:
        return None

def post_frame(base_url: str, payload: dict):
    try:
        response = requests.post(f"{base_url.rstrip('/')}/api/v1/ingest", json=payload, timeout=8)
        response.raise_for_status()
        return response.json(), None
    except requests.HTTPError as exc:
        body = exc.response.text if exc.response is not None else str(exc)
        return None, f"Backend rejected the payload: {body}"
    except requests.RequestException as exc:
        return None, f"Could not reach backend: {exc}"
