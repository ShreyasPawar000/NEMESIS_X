import json
import urllib.request
import urllib.error
from pathlib import Path
from collections import defaultdict

# Project paths
PROJECT_ROOT = Path(__file__).resolve().parent.parent

TRACKING_FILE = (
    PROJECT_ROOT / "output" / "tracking_data" / "Traffic_Test.json"
)

API_URL = "http://127.0.0.1:8000/api/v1/ingest"

# Original video dimensions
VIDEO_WIDTH = 1280
VIDEO_HEIGHT = 720

def normalize_bbox(bbox):
    x1, y1, x2, y2 = bbox

    return [
        x1 / VIDEO_WIDTH,
        y1 / VIDEO_HEIGHT,
        x2 / VIDEO_WIDTH,
        y2 / VIDEO_HEIGHT
    ]


def send_frame(payload):
    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        API_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def main():
    print("Loading ByteTrack data...")

    with open(TRACKING_FILE, "r", encoding="utf-8") as file:
        records = json.load(file)

    frames = defaultdict(list)
    timestamps = {}

    for record in records:
        frame_id = record["frame"]
        frames[frame_id].append(record)
        timestamps.setdefault(frame_id, record["timestamp"])

    print("Detection records:", len(records))
    print("Unique frames:", len(frames))

    print("\nSending frames to NEMESIS-X Backend...")

    total_sent = 0
    total_alerts = 0

    for frame_id in sorted(frames):

        detections = []

        for record in frames[frame_id]:
            detections.append({
                "track_id": record["track_id"],
                "label": record["object"],
                "confidence": record["confidence"],
                "bbox": normalize_bbox(record["bbox"])
            })

        payload = {
            "video_id": "Traffic_Test",
            "frame_id": frame_id,
            "timestamp": timestamps[frame_id],
            "detections": detections,
            "frame_embedding": None
        }

        try:
            result = send_frame(payload)
            total_sent += 1

            if result.get("alert_triggered"):
                total_alerts += 1
                print(
                    "ALERT:",
                    frame_id,
                    result.get("score")
                )

            if total_sent % 100 == 0:
                print(f"Processed {total_sent}/{len(frames)} frames")

        except urllib.error.HTTPError as error:
            print("HTTP Error:", error.code)
            print(error.read().decode("utf-8"))
            break

        except Exception as error:
            print("Error:", error)
            break

    print("\n========== INTEGRATION SUMMARY ==========")
    print("Frames sent:", total_sent)
    print("Alerts received:", total_alerts)


if __name__ == "__main__":
    main()