import json
import math

from pathlib import Path
from collections import Counter


# ==========================================
# PATH CONFIGURATION
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent

MOVEMENT_DIR = BASE_DIR / "output" / "movement_analysis_v2"
SPATIAL_DIR = BASE_DIR / "output" / "spatial_analysis"
TRACKING_DIR = BASE_DIR / "output" / "tracking_data"

OUTPUT_DIR = BASE_DIR / "output" / "temporal_event_analysis_v4_2_1"


# ==========================================
# CONFIGURATION
# ==========================================

PORTABLE_OBJECTS = {
    "backpack", "handbag", "suitcase",
    "umbrella", "bottle"
}

PERSON_CLASS = "person"

MIN_ASSOCIATION_OBSERVATIONS = 5

ASSOCIATION_DISTANCE_THRESHOLD = 0.08

MIN_HORIZONTAL_OVERLAP = 0.35

AMBIGUITY_SCORE_MARGIN = 0.10


# ==========================================
# DATA LOADER
# ==========================================

def load_json(path):

    if not path.exists():
        raise FileNotFoundError(f"Missing file: {path}")

    with open(path, encoding="utf-8") as file:
        return json.load(file)


# ==========================================
# INPUT VALIDATION
# ==========================================

def validate_inputs(video_name):

    movement = load_json(
        MOVEMENT_DIR / f"{video_name}_movement_v2.json"
    )

    spatial = load_json(
        SPATIAL_DIR / f"{video_name}_spatial.json"
    )

    tracking = load_json(
        TRACKING_DIR / f"{video_name}.json"
    )

    if movement.get("video") != video_name:
        raise ValueError("Movement video mismatch")

    if spatial.get("video") != video_name:
        raise ValueError("Spatial video mismatch")

    required = {
        "frame", "timestamp", "track_id",
        "object", "centroid", "bbox"
    }

    for index, record in enumerate(tracking):

        missing = required - record.keys()

        if missing:
            raise ValueError(
                f"Tracking record {index} missing: {missing}"
            )

        if len(record["bbox"]) != 4:
            raise ValueError(
                f"Invalid bounding box at record {index}"
            )

    return movement, spatial, tracking


# ==========================================
# TRACK INDEX
# ==========================================

def build_track_index(tracking):

    tracks = {}

    for record in tracking:

        track_id = record["track_id"]

        tracks.setdefault(track_id, []).append(record)

    for track_id in tracks:

        tracks[track_id].sort(
            key=lambda item: item["timestamp"]
        )

    return tracks


# ==========================================
# BOUNDING BOX GEOMETRY
# ==========================================

def calculate_box_geometry(person, obj):

    px1, py1, px2, py2 = person["bbox"]

    ox1, oy1, ox2, oy2 = obj["bbox"]

    person_width = max(1, px2 - px1)

    person_height = max(1, py2 - py1)

    object_width = max(1, ox2 - ox1)

    object_height = max(1, oy2 - oy1)

    horizontal_overlap = max(
        0,
        min(px2, ox2) - max(px1, ox1)
    )

    vertical_overlap = max(
        0,
        min(py2, oy2) - max(py1, oy1)
    )

    horizontal_overlap_ratio = (
        horizontal_overlap /
        min(person_width, object_width)
    )

    object_center_x = (ox1 + ox2) / 2

    object_center_y = (oy1 + oy2) / 2

    vertical_position = (
        object_center_y - py1
    ) / person_height

    horizontal_alignment = (
        1 - min(
            1,
            abs(object_center_x - (px1 + px2) / 2)
            / (person_width + object_width)
        )
    )

    return {

        "horizontal_overlap": round(
            horizontal_overlap, 2
        ),

        "vertical_overlap": round(
            vertical_overlap, 2
        ),

        "horizontal_overlap_ratio": round(
            horizontal_overlap_ratio, 4
        ),

        "vertical_position_ratio": round(
            vertical_position, 4
        ),

        "horizontal_alignment": round(
            horizontal_alignment, 4
        ),

        "object_center_above_person_center": (
            object_center_y < (py1 + py2) / 2
        )

    }


# ==========================================
# GEOMETRY ANALYSIS
# ==========================================

def analyze_geometry(person, obj, object_class):

    geometry = calculate_box_geometry(person, obj)

    overlap = geometry["horizontal_overlap_ratio"]

    vertical = geometry["vertical_position_ratio"]

    if object_class == "umbrella":

        plausible_position = (
            -0.10 <= vertical <= 0.45
        )

    elif object_class == "backpack":

        plausible_position = (
            -0.10 <= vertical <= 0.85
        )

    else:

        plausible_position = (
            -0.10 <= vertical <= 1.10
        )

    geometry["plausible_vertical_position"] = (
        plausible_position
    )

    geometry["geometry_valid"] = (
        overlap >= MIN_HORIZONTAL_OVERLAP
        and plausible_position
    )

    return geometry


# ==========================================
# MOVEMENT SIMILARITY
# ==========================================

def calculate_movement_similarity(
    person_data,
    object_data,
    start_time,
    end_time
):

    person_positions = {
        item["frame"]: item
        for item in person_data
        if start_time <= item["timestamp"] <= end_time
    }

    object_positions = {
        item["frame"]: item
        for item in object_data
        if start_time <= item["timestamp"] <= end_time
    }

    common_frames = sorted(
        set(person_positions) & set(object_positions)
    )

    if len(common_frames) < MIN_ASSOCIATION_OBSERVATIONS:
        return None

    direction_scores = []

    relative_distances = []

    geometry_scores = []

    valid_geometry_frames = 0

    for frame in common_frames:

        person = person_positions[frame]

        obj = object_positions[frame]

        geometry = analyze_geometry(
            person, obj, obj["object"]
        )

        geometry_scores.append(
            geometry["horizontal_overlap_ratio"]
        )

        if geometry["geometry_valid"]:
            valid_geometry_frames += 1

    for index in range(1, len(common_frames)):

        frame_a = common_frames[index - 1]

        frame_b = common_frames[index]

        p1 = person_positions[frame_a]["centroid"]

        p2 = person_positions[frame_b]["centroid"]

        o1 = object_positions[frame_a]["centroid"]

        o2 = object_positions[frame_b]["centroid"]

        pdx = p2[0] - p1[0]

        pdy = p2[1] - p1[1]

        odx = o2[0] - o1[0]

        ody = o2[1] - o1[1]

        person_speed = math.hypot(pdx, pdy)

        object_speed = math.hypot(odx, ody)

        if person_speed > 0 and object_speed > 0:

            similarity = (
                pdx * odx + pdy * ody
            ) / (person_speed * object_speed)

            direction_scores.append(similarity)

        relative_distances.append(
            math.hypot(
                p2[0] - o2[0],
                p2[1] - o2[1]
            )
        )

    if not direction_scores:
        return None

    distance_range = (
        max(relative_distances) - min(relative_distances)
    )

    average_distance = (
        sum(relative_distances) / len(relative_distances)
    )

    distance_stability = None

    if average_distance > 0:

        distance_stability = (
            distance_range / average_distance
        )

    geometry_ratio = (
        valid_geometry_frames / len(common_frames)
    )

    average_overlap = (
        sum(geometry_scores) / len(geometry_scores)
    )

    return {

        "shared_observations": len(common_frames),

        "direction_similarity": round(
            sum(direction_scores) / len(direction_scores), 4
        ),

        "relative_distance_range_pixels": round(
            distance_range, 2
        ),

        "relative_distance_stability": round(
            distance_stability, 4
        ) if distance_stability is not None else None,

        "geometry_valid_frames": valid_geometry_frames,

        "geometry_consistency": round(
            geometry_ratio, 4
        ),

        "average_horizontal_overlap": round(
            average_overlap, 4
        )

    }


# ==========================================
# PERSON-OBJECT ASSOCIATION
# ==========================================

def analyze_person_object_associations(
    tracks,
    relationships
):

    associations = []

    for relationship in relationships:

        first_id, second_id = relationship["track_ids"]

        first_object = relationship["object_1"]

        second_object = relationship["object_2"]

        if (
            first_object == PERSON_CLASS
            and second_object in PORTABLE_OBJECTS
        ):

            person_id = first_id

            object_id = second_id

            object_class = second_object

        elif (
            second_object == PERSON_CLASS
            and first_object in PORTABLE_OBJECTS
        ):

            person_id = second_id

            object_id = first_id

            object_class = first_object

        else:

            continue

        if person_id not in tracks or object_id not in tracks:
            continue

        average_distance = relationship.get(
            "average_distance"
        )

        if (
            average_distance is None
            or average_distance > ASSOCIATION_DISTANCE_THRESHOLD
        ):
            continue

        movement = calculate_movement_similarity(
            tracks[person_id],
            tracks[object_id],
            relationship["first_seen"],
            relationship["last_seen"]
        )

        if movement is None:
            classification = "insufficient_evidence"

            score = 0.0

        else:

            direction = movement["direction_similarity"]

            stability = movement["relative_distance_stability"]

            geometry = movement["geometry_consistency"]

            score = (
                0.35 * max(0, direction)
                + 0.40 * geometry
                + 0.25 * (
                    max(0, 1 - min(stability or 1, 1))
                )
            )

            if (
                movement["shared_observations"]
                >= MIN_ASSOCIATION_OBSERVATIONS
                and direction >= 0.70
                and geometry >= 0.70
                and stability is not None
                and stability <= 0.25
            ):

                classification = "strong_association_candidate"

            elif (
                direction >= 0.30
                and geometry >= 0.40
            ):

                classification = "possible_association"

            else:

                classification = "weak_association"

        associations.append({

            "person_track_id": person_id,

            "object_track_id": object_id,

            "object_class": object_class,

            "start_time": relationship["first_seen"],

            "end_time": relationship["last_seen"],

            "spatial_evidence": relationship["evidence_category"],

            "movement_analysis": movement,

            "association_score": round(score, 4),

            "association_classification": classification,

            "association_ambiguity": False

        })

    return associations


# ==========================================
# INTERVAL-AWARE COMPETING ASSOCIATION RESOLUTION
# ==========================================

def _positive_overlap(start_a, end_a, start_b, end_b, epsilon=0.05):
    """Return the positive-duration overlap; touching endpoints are not overlap."""
    overlap_start = max(float(start_a), float(start_b))
    overlap_end = min(float(end_a), float(end_b))

    if overlap_end - overlap_start <= epsilon:
        return None

    return overlap_start, overlap_end


def _append_or_merge_segment(segments, segment):
    """Merge adjacent segments with the same decision for compact output."""
    if segments:
        previous = segments[-1]
        same_decision = (
            previous["decision"] == segment["decision"]
            and previous.get("competing_person_track_ids", [])
                == segment.get("competing_person_track_ids", [])
        )
        adjacent = abs(previous["end_time"] - segment["start_time"]) <= 1e-6

        if same_decision and adjacent:
            previous["end_time"] = segment["end_time"]
            return

    segments.append(segment)


def resolve_competing_associations(associations):
    """
    Resolve person-vs-person candidates for the same tracked object,
    independently over each positive-duration time segment.

    Important:
    - Intervals that only touch at one timestamp do not compete.
    - A candidate is downgraded only during the time it actually loses.
    - Different person tracks compete; duplicate episodes for the same
      person do not compete against one another.
    - Original association evidence and scores are preserved.
    """

    eligible_classes = {
        "strong_association_candidate",
        "possible_association",
        "weak_association"
    }

    grouped = {}

    for index, association in enumerate(associations):
        association["original_classification"] = (
            association["association_classification"]
        )
        association["resolution_segments"] = []

        if (
            association["association_classification"] in eligible_classes
            and association.get("movement_analysis") is not None
            and association.get("association_score", 0) > 0
            and float(association["end_time"]) >
                float(association["start_time"])
        ):
            grouped.setdefault(
                association["object_track_id"], []
            ).append((index, association))

    for object_id, indexed_candidates in grouped.items():

        boundaries = sorted({
            float(value)
            for _, candidate in indexed_candidates
            for value in (
                candidate["start_time"],
                candidate["end_time"]
            )
        })

        for segment_start, segment_end in zip(boundaries, boundaries[1:]):

            if segment_end - segment_start <= 0.05:
                continue

            midpoint = (segment_start + segment_end) / 2

            active = [
                (index, candidate)
                for index, candidate in indexed_candidates
                if float(candidate["start_time"]) <= midpoint
                < float(candidate["end_time"])
            ]

            if not active:
                continue

            # Keep only the highest-scoring episode per person for this
            # object and segment. Other episodes from the same person are
            # recorded as duplicates, not as competing people.
            by_person = {}

            for index, candidate in active:
                person_id = candidate["person_track_id"]
                by_person.setdefault(person_id, []).append(
                    (index, candidate)
                )

            person_winners = []

            for person_id, person_candidates in by_person.items():
                person_candidates.sort(
                    key=lambda item: item[1]["association_score"],
                    reverse=True
                )
                person_winners.append(person_candidates[0])

                for duplicate_index, duplicate in person_candidates[1:]:
                    _append_or_merge_segment(
                        duplicate["resolution_segments"],
                        {
                            "start_time": round(segment_start, 3),
                            "end_time": round(segment_end, 3),
                            "decision": "duplicate_same_person_episode",
                            "competing_person_track_ids": []
                        }
                    )

            person_winners.sort(
                key=lambda item: item[1]["association_score"],
                reverse=True
            )

            if len(person_winners) == 1:
                winner_index, winner = person_winners[0]
                decision = "uncontested"
                competitors = []

                _append_or_merge_segment(
                    winner["resolution_segments"],
                    {
                        "start_time": round(segment_start, 3),
                        "end_time": round(segment_end, 3),
                        "decision": decision,
                        "competing_person_track_ids": competitors
                    }
                )
                continue

            top_index, top_candidate = person_winners[0]
            second_candidate = person_winners[1][1]

            top_score = float(top_candidate["association_score"])
            second_score = float(second_candidate["association_score"])
            score_gap = top_score - second_score

            if score_gap <= AMBIGUITY_SCORE_MARGIN:
                # All candidates within the margin of the best score are
                # ambiguous for this segment.
                ambiguous_people = [
                    candidate["person_track_id"]
                    for _, candidate in person_winners
                    if top_score - float(candidate["association_score"])
                    <= AMBIGUITY_SCORE_MARGIN
                ]

                for index, candidate in person_winners:
                    if candidate["person_track_id"] in ambiguous_people:
                        decision = "ambiguous"
                        competitors = [
                            person_id for person_id in ambiguous_people
                            if person_id != candidate["person_track_id"]
                        ]
                    else:
                        decision = "competing"
                        competitors = ambiguous_people

                    _append_or_merge_segment(
                        candidate["resolution_segments"],
                        {
                            "start_time": round(segment_start, 3),
                            "end_time": round(segment_end, 3),
                            "decision": decision,
                            "competing_person_track_ids": competitors
                        }
                    )
            else:
                winner_person_id = top_candidate["person_track_id"]

                for index, candidate in person_winners:
                    if candidate["person_track_id"] == winner_person_id:
                        decision = "best_supported_candidate"
                        competitors = [
                            item["person_track_id"]
                            for _, item in person_winners
                            if item["person_track_id"] != winner_person_id
                        ]
                    else:
                        decision = "competing"
                        competitors = [winner_person_id]

                    _append_or_merge_segment(
                        candidate["resolution_segments"],
                        {
                            "start_time": round(segment_start, 3),
                            "end_time": round(segment_end, 3),
                            "decision": decision,
                            "competing_person_track_ids": competitors
                        }
                    )

    # Derive a precise record-level label while preserving segment decisions.
    for association in associations:

        segments = association.get("resolution_segments", [])
        decisions = {segment["decision"] for segment in segments}

        association["segment_decision_summary"] = {
            decision: sum(1 for segment in segments if segment["decision"] == decision)
            for decision in sorted(decisions)
        }

        if not decisions:
            label = association["original_classification"]
            ambiguous = False
        elif decisions <= {"ambiguous"}:
            label, ambiguous = "ambiguous_association", True
        elif "ambiguous" in decisions:
            label, ambiguous = "partially_ambiguous_association", True
        elif decisions <= {"competing"}:
            label, ambiguous = "competing_candidate", True
        elif decisions <= {"best_supported_candidate"}:
            label, ambiguous = "best_supported_candidate", False
        elif "competing" in decisions:
            label, ambiguous = "partially_competing_candidate", False
        elif "best_supported_candidate" in decisions:
            # Wins every contested segment; this is not partial competition.
            label, ambiguous = "best_supported_candidate", False
        else:
            label, ambiguous = association["original_classification"], False

        association["association_classification"] = label
        association["association_ambiguity"] = ambiguous

    return associations


# ==========================================
# EVENT SUMMARY
# ==========================================

def generate_summary(associations):

    counts = Counter(
        item["association_classification"] for item in associations
    )

    segment_counts = Counter()
    segment_durations = Counter()

    for association in associations:
        for segment in association.get("resolution_segments", []):
            decision = segment["decision"]
            duration = max(
                0.0,
                float(segment["end_time"]) - float(segment["start_time"])
            )
            segment_counts[decision] += 1
            segment_durations[decision] += duration

    return {
        "total_associations": len(associations),
        "strong_candidates": counts["strong_association_candidate"],
        "possible_candidates": counts["possible_association"],
        "weak_candidates": counts["weak_association"],
        "best_supported_candidates": counts["best_supported_candidate"],
        "ambiguous_associations": counts["ambiguous_association"],
        "partially_ambiguous_associations": counts[
            "partially_ambiguous_association"
        ],
        "competing_candidates": counts["competing_candidate"],
        "partially_competing_candidates": counts[
            "partially_competing_candidate"
        ],
        "insufficient_evidence": counts["insufficient_evidence"],
        "segment_summary": {
            "segment_counts": dict(sorted(segment_counts.items())),
            "segment_durations_seconds": {
                key: round(value, 3)
                for key, value in sorted(segment_durations.items())
            },
            "duration_note": (
                "Durations are summed per association record. Overlapping "
                "candidate intervals for the same object may count the same "
                "clock-time interval more than once."
            )
        }
    }


# VIDEO ANALYSIS
# ==========================================

def analyze_video(video_name):

    print("\n" + "=" * 65)

    print(f"PROCESSING VIDEO: {video_name}")

    print("=" * 65)

    movement, spatial, tracking = validate_inputs(video_name)

    tracks = build_track_index(tracking)

    relationships = spatial.get("relationships", [])

    associations = analyze_person_object_associations(
        tracks,
        relationships
    )

    associations = resolve_competing_associations(
        associations
    )

    summary = generate_summary(associations)

    result = {

        "video": video_name,

        "module": "Temporal Event Reasoning V4.2.1 - Tuple Indexing Fix",

        "input_sources": {

            "movement_analysis": str(MOVEMENT_DIR),

            "spatial_analysis": str(SPATIAL_DIR),

            "tracking_data": str(TRACKING_DIR)

        },

        "analysis_settings": {

            "minimum_observations": MIN_ASSOCIATION_OBSERVATIONS,

            "minimum_horizontal_overlap": MIN_HORIZONTAL_OVERLAP,

            "ambiguity_score_margin": AMBIGUITY_SCORE_MARGIN,
            "minimum_positive_overlap_seconds": 0.05,
            "resolution_method": "interval-aware per-object, per-person temporal segments",
            "record_labeling": "full_vs_partial_ambiguity_and_competition",
            "segment_summary": "counts_and_association_seconds_by_decision"

        },

        "summary": summary,

        "associations": associations

    }

    output_file = (
        OUTPUT_DIR /
        f"{video_name}_temporal_events_v4_2_1.json"
    )

    with open(output_file, "w", encoding="utf-8") as file:

        json.dump(
            result,
            file,
            indent=4,
            ensure_ascii=False
        )

    print("Movement tracks:", movement["total_tracks"])

    print("Spatial episodes:", len(relationships))

    print("Tracking observations:", len(tracking))

    print("Associations:", len(associations))

    print("\nAssociation summary:")

    for key, value in summary.items():

        print(f"{key}: {value}")

    print("Saved:", output_file.name)

    return result


# ==========================================
# MAIN
# ==========================================

def main():

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    movement_files = sorted(
        MOVEMENT_DIR.glob("*_movement_v2.json")
    )

    if not movement_files:

        print("No movement analysis files found.")

        return

    successful = 0

    failed = 0

    for file in movement_files:

        video_name = file.name.replace(
            "_movement_v2.json", ""
        )

        try:

            analyze_video(video_name)

            successful += 1

        except Exception as error:

            failed += 1
            print(f"Failed to process {video_name}: {error}")

    print("\n" + "=" * 65)

    print("TEMPORAL EVENT REASONING V4.2.1 RESULTS")

    print("=" * 65)

    print("Successfully processed:", successful)

    print("Failed:", failed)

    print("Output directory:", OUTPUT_DIR)


if __name__ == "__main__":

    main()  