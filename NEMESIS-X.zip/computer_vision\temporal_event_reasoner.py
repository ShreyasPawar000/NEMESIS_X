import json
from pathlib import Path


# ==================================================
# PATH CONFIGURATION
# ==================================================

BASE_DIR = Path(__file__).resolve().parent.parent

MOVEMENT_DIR = BASE_DIR / "output" / "movement_analysis_v2"
SPATIAL_DIR = BASE_DIR / "output" / "spatial_analysis"

OUTPUT_DIR = BASE_DIR / "output" / "temporal_event_analysis"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ==================================================
# LOAD JSON
# ==================================================

def load_json(file_path):

    with open(file_path, "r", encoding="utf-8") as file:
        return json.load(file)


# ==================================================
# BUILD TRACK LOOKUP
# ==================================================

def build_track_lookup(movement_data):

    track_lookup = {}

    for track in movement_data.get("track_summaries", []):

        track_id = track.get("track_id")

        if track_id is not None:
            track_lookup[track_id] = track

    return track_lookup


# ==================================================
# IDENTIFY EVENT TYPE
# ==================================================

def identify_event_type(object_1, object_2):

    if object_1 == "person" and object_2 == "person":
        return "person_person_proximity"

    if object_1 == "person" or object_2 == "person":
        return "person_object_proximity"

    return "object_object_proximity"


# ==================================================
# GENERATE EVENT DESCRIPTION
# ==================================================

def generate_description(relationship, track_lookup):

    track_ids = relationship["track_ids"]

    object_1 = relationship["object_1"]
    object_2 = relationship["object_2"]

    track_1 = track_lookup.get(track_ids[0], {})
    track_2 = track_lookup.get(track_ids[1], {})

    status_1 = track_1.get(
        "movement_status", "unknown"
    )

    status_2 = track_2.get(
        "movement_status", "unknown"
    )

    return (
        f"{object_1} (Track {track_ids[0]}) and "
        f"{object_2} (Track {track_ids[1]}) "
        f"were observed near each other. "
        f"Their spatial relationship was "
        f"{relationship.get('relationship', 'unknown')}. "
        f"Track movement statuses: "
        f"{status_1} and {status_2}."
    )


# ==================================================
# TEMPORAL EVENT REASONING
# ==================================================

def analyze_video(movement_file, spatial_file):

    movement_data = load_json(movement_file)
    spatial_data = load_json(spatial_file)

    video_name = movement_data["video"]

    if spatial_data.get("video") != video_name:
        raise ValueError("Video names do not match.")

    track_lookup = build_track_lookup(movement_data)

    events = []

    relationships = spatial_data.get(
        "relationships", []
    )

    for relationship in relationships:

        track_ids = relationship.get("track_ids", [])

        if len(track_ids) != 2:
            continue

        track_1 = track_lookup.get(track_ids[0])
        track_2 = track_lookup.get(track_ids[1])

        if track_1 is None or track_2 is None:
            continue

        object_1 = relationship["object_1"]
        object_2 = relationship["object_2"]

        event_type = identify_event_type(
            object_1, object_2
        )

        first_seen = relationship["first_seen"]
        last_seen = relationship["last_seen"]

        event_id = (
            f"{video_name}_"
            f"{track_ids[0]}_{track_ids[1]}_"
            f"{relationship['episode_id']}_"
            f"{first_seen}"
        )

        event = {

            "event_id": event_id,

            "event_type": event_type,

            "video": video_name,

            "track_ids": track_ids,

            "objects": [
                object_1,
                object_2
            ],

            "timeline": {

                "start_time": first_seen,

                "end_time": last_seen,

                "duration_seconds":
                    relationship["duration_seconds"]

            },

            "spatial_evidence": {

                "relationship":
                    relationship["relationship"],

                "proximity_type":
                    relationship["proximity_type"],

                "evidence_category":
                    relationship["evidence_category"],

                "observations":
                    relationship["observations"],

                "average_distance":
                    relationship["average_distance"]

            },

            "movement_context": {

                str(track_ids[0]):
                    track_1["movement_status"],

                str(track_ids[1]):
                    track_2["movement_status"]

            },

            "description": generate_description(
                relationship, track_lookup
            )

        }

        events.append(event)

    # Sort events chronologically

    events.sort(
        key=lambda event: event["timeline"]["start_time"]
    )

    # ==================================================
    # SUMMARY
    # ==================================================

    summary = {

        "total_events": len(events),

        "person_person_proximity": 0,

        "person_object_proximity": 0,

        "object_object_proximity": 0,

        "reliable_evidence": 0,

        "short_encounters": 0,

        "uncertain_evidence": 0

    }

    for event in events:

        summary[event["event_type"]] += 1

        evidence = event["spatial_evidence"][
            "evidence_category"
        ]

        if evidence == "reliable":
            summary["reliable_evidence"] += 1

        elif evidence == "short_encounter":
            summary["short_encounters"] += 1

        else:
            summary["uncertain_evidence"] += 1

    # ==================================================
    # OUTPUT
    # ==================================================

    output = {

        "video": video_name,

        "module": "Temporal Event Reasoning V1",

        "input_sources": {

            "movement_analysis":
                movement_file.name,

            "spatial_analysis":
                spatial_file.name

        },

        "summary": summary,

        "events": events

    }

    output_file = (
        OUTPUT_DIR /
        f"{video_name}_temporal_events.json"
    )

    with open(output_file, "w", encoding="utf-8") as file:

        json.dump(output, file, indent=4)

    print(f"\nVideo: {video_name}")
    print("Events generated:", len(events))
    print("Summary:", summary)
    print("Saved:", output_file)


# ==================================================
# MAIN
# ==================================================

def main():

    movement_files = sorted(
        MOVEMENT_DIR.glob("*_movement_v2.json")
    )

    if not movement_files:

        print("No movement analysis files found!")
        return

    print("=" * 55)
    print("NEMESIS-X - TEMPORAL EVENT REASONING V1")
    print("=" * 55)

    processed = 0

    for movement_file in movement_files:

        video_name = movement_file.name.replace(
            "_movement_v2.json", ""
        )

        spatial_file = (
            SPATIAL_DIR /
            f"{video_name}_spatial.json"
        )

        if not spatial_file.exists():

            print(
                f"Skipping {video_name}: "
                "Spatial file not found."
            )

            continue

        try:

            analyze_video(
                movement_file,
                spatial_file
            )

            processed += 1

        except Exception as error:

            print(
                f"Error processing {video_name}: {error}"
            )

    print("\n" + "=" * 55)
    print("TEMPORAL REASONING COMPLETED")
    print("Videos processed:", processed)
    print("Output directory:", OUTPUT_DIR)
    print("=" * 55)


if __name__ == "__main__":
    main()